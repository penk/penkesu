#ifndef CONFIG_USER_H
#define CONFIG_USER_H

#include "config_common.h"

//#define ONESHOT_TIMEOUT 3000
//#define AUTO_SHIFT_TIMEOUT 200

#endif