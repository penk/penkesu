koda
---

A low-profile 48 key ortho supporting family13 keycaps.

Designed by Odd Rocket. 
